import React from 'react';
import {ProfileInfo} from "../components/ProfileInfo.js"
//import { TripContainer } from "../components/TripContainer.js";
import "../styles/Userpage.css";
//import {Trips} from "../components/trips";


const UserPage  = () => {

  return(
      <div className="profile-container">
        <ProfileInfo />

      </div>
  )
};
//E4I8FwHiseUh00SW7IRvPfF29sq1

export default UserPage;