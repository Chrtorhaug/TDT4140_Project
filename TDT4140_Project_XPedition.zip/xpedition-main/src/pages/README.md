### Folder to add all pages except for index.js and App.js

Make sure to add pages in this structure:
client/src/pages/pageName/pageName.jsx
